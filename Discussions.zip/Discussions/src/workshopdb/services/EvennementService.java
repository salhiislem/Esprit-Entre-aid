/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import workshopdb.entities.Discussion;
import workshopdb.entities.Evennement;
import workshopdb.utils.Mydb1;

/**
 *
 * @author Hajbi
 */
public class EvennementService {
    
    Connection connexion;

    public EvennementService() {
        connexion = Mydb1.getInstance().getConnection();
    }
    
     public static String valDate(String date)
    {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/mm/yyyy");
        try
        {
            f.parse(date);
            System.out.println("date valide");
        }catch(Exception e0){
            System.out.println("date invalide");
        }
        return date;
    }
    
    
      public void ajouterEvennement(Evennement e) throws SQLException
    {
        String req=" INSERT INTO `Evennement` (`nom`,`description`,`date`) VALUES ('"+e.getNom()+"','"+e.getDescription()+"','"+e.getDate()+"')";
        
        Statement stm= connexion.createStatement();
        stm.executeUpdate(req);    
    }
    
    public List<Evennement> getAllEvennements() throws SQLException
    {
        List<Evennement> evennements = new ArrayList <>();
        String req="select * from Evennement";
        Statement stm= connexion.createStatement();
         ResultSet rst = stm.executeQuery(req);
         
         while(rst.next()){
             Evennement e =new Evennement(rst.getInt("idE"),rst.getString("nom"),rst.getString("description"),rst.getString("date"));
             evennements.add(e);  
         }
         return evennements;
     }
    
     public void modifierEvennement(int i,String s1,String s2) throws SQLException{
        String req=" update evennement set nom=? ,description=? WHERE idE=?";
        String query=" select * from evennement WHERE idE="+i;
        PreparedStatement ps=connexion.prepareStatement(req);
        Statement stm=connexion.createStatement();
        ResultSet res=stm.executeQuery(query);
        if(res.next())
        {
        ps.setString(1,s1);
        ps.setString(2,s2);
        ps.setInt(3,i);
        ps.executeUpdate();
        System.out.println("update terminé ");
        }
        else
            System.out.println("Evennement inexistant");
     }
    
    public void modifierEvennement1(int i, String s1) throws SQLException{
        String req=" update evennement set nom=? WHERE idE=? ";
        String query=" select * from evennement WHERE idE="+i;
        PreparedStatement ps=connexion.prepareStatement(req);
        Statement stm=connexion.createStatement();
        ResultSet res=stm.executeQuery(query);
        if(res.next())
        {
        ps.setString(1,s1);
        ps.setInt(2,i);
        ps.executeUpdate();
        System.out.println("nom modifié");
        }
        else
            System.out.println("evennement inexistant");
        
    }
    public void modifierEvennement2(int i, String s2) throws SQLException{
        String req=" update evennement set description=? WHERE idE=? ";
        String query=" select * from evennement WHERE idE="+i;
        PreparedStatement ps=connexion.prepareStatement(req);
        Statement stm=connexion.createStatement();
        ResultSet res=stm.executeQuery(query);
        if(res.next())
        {
        ps.setString(1,s2);
        ps.setInt(2,i);
        ps.executeUpdate();
        System.out.println("description modifié");
        }
        else
            System.out.println("Evennement inexistant");
        
    }
    
    public void supprimerEvennement(int i) throws SQLException{
        String req = "DELETE FROM evennement WHERE idE=?";
         PreparedStatement ps = connexion.prepareStatement(req);
        ps.setInt(1,i);
        
        ps.executeUpdate();
        System.out.println("Evennement supprimé !");
        }
    
}
