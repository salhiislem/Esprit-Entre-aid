/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import workshopdb.entities.Etudiant;
import workshopdb.entities.Planning;
import workshopdb.entities.InscriPlanning;
import workshopdb.utils.Mydb1;

/**
 *
 * @author Hajbi
 */
public class InscritEtudiant {
    
     Connection connexion;

    public InscritEtudiant() {
        connexion = Mydb1.getInstance().getConnection();
    }
    
     public void InscritPlanning(Planning p,Etudiant e) throws SQLException
    {
        String req=" INSERT INTO `Inscriplanning` (`nomP`,`nomE`,`prenomE`) VALUES ('"+p.getNom()+"','"+e.getNomE()+"','"+e.getPrenomE()+"')";
        
        Statement stm= connexion.createStatement();
        stm.executeUpdate(req);
    }
    
    public List<InscriPlanning> getAllInscriPlannings() throws SQLException
    {
        Planning p = null;
        List<InscriPlanning> inscriPlannings = new ArrayList <>();
        String req="select * from inscriplanning";
        Statement stm= connexion.createStatement();
         ResultSet rst = stm.executeQuery(req);
         
         while((rst.next()) && ("nomP".equals(p.getNom()))){
             System.out.print(rst.getString("nomP")+"\t");
             System.out.print(rst.getString("nomE")+"\t");
             System.out.print(rst.getString("prenomE")+"\t");
             System.out.println();  
         }
         return inscriPlannings;
     }
}
