/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.applet.Main;
import workshopdb.entities.Discussion;
import workshopdb.entities.Evennement;
import workshopdb.services.EvennementService;
import java.sql.Date;
import static workshopdb.services.EvennementService.valDate;

/**
 *
 * @author Hajbi
 */
public class Main2 {
    
     public static void main(String[] args) throws SQLException{
       
       Mydb1 database = Mydb1.getInstance();
       Connection connexion = Mydb1.getInstance().getConnection();
       EvennementService evennementService= new EvennementService();
       
       Evennement e1 = new Evennement("final","glascow",valDate("30/05/2002"));
       Evennement e2 = new Evennement("final","lisabon",valDate("24/05/2014"));
       
        try {
            evennementService.ajouterEvennement(e1);
            //evennementService.ajouterEvennement(e2);
            System.out.println("evennement ajouté");
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("erreur lors de l'ajout");
        }
        
        try {
            for(Evennement ee: evennementService.getAllEvennements())
            {
                System.out.println(ee);
            }
        } catch (SQLException ex2) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex2);    
        }
       
         try {
           evennementService.modifierEvennement(4,"final","kiev");
      }catch (SQLException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("erreur lors de la modification");
        }
            
       try {
           evennementService.modifierEvennement1(3,"cardiff");
      }catch (SQLException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("erreur lors de la modification");
        }
       
       /*try {
           evennementService.modifierEvennement2(3,"final");
      }catch (SQLException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("erreur lors de la modification");
        }
        */
        
        try {      
            evennementService.supprimerEvennement(1);
        }catch (SQLException e4) {
            //Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, e4);
            //System.out.println("erreur lors de la suppression");
        }
         
     }
}
