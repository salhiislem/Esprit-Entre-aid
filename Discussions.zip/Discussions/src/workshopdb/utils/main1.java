/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.applet.Main;
import workshopdb.entities.Discussion;
import workshopdb.services.DiscussionService;

/**
 *
 * @author Hajbi
 */
public class main1 {
    
    public static void main(String[] args) throws SQLException {
       
       Mydb1 database = Mydb1.getInstance();
       Connection connexion = Mydb1.getInstance().getConnection();
       DiscussionService discussionService= new DiscussionService();
       
       Discussion d1=new Discussion("python","les bibliothèque");
       Discussion d2=new Discussion("c++","les classes");
        
       try {
            discussionService.ajouterDiscussion(d1);
            discussionService.ajouterDiscussion(d2);
            System.out.println("produit ajouté");
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("erreur lors de l'ajout");
        }
        
       try {
            for(Discussion dd: discussionService.getAllDiscussions())
            {
                System.out.println(dd);
            }
        } catch (SQLException e2) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, e2);
            
        }
       
       try {
           discussionService.modifierDiscussion(2,"java","classe");
      }catch (SQLException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("erreur lors de la modification");
        }
            
       try {
           discussionService.modifierDiscussion1(2,"uml");
      }catch (SQLException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("erreur lors de la modification");
        }
       
       /*try {
           discussionService.modifierDiscussion2(1,"diag de classe");
      }catch (SQLException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("erreur lors de la modification");
        }*/
       try {      
            discussionService.supprimerDiscussion(3);
        }catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("erreur lors de la suppression");
        }
    }
}
