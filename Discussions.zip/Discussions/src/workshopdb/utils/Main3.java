/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.applet.Main;
import workshopdb.entities.Planning;
import static workshopdb.services.EvennementService.valDate;
import workshopdb.services.PlanningService;

/**
 *
 * @author Hajbi
 */
public class Main3 {
    public static void main(String[] args) throws SQLException {
       
       Mydb1 database = Mydb1.getInstance();
       Connection connexion = Mydb1.getInstance().getConnection();
       PlanningService planningService= new PlanningService();
       
       Planning p1 = new Planning("revision","web","sadkaoui moez",15,"esprit",valDate("15/09/2018"));
       Planning p2 = new Planning("final","lisabon","hmidi anouar",20,"sesame",valDate("12/08/2015"));
       
       /* try {
       //planningService.ajouterPlanning(p1);
       planningService.ajouterPlanning(p2);
            System.out.println("planning ajouté");
        } catch (Exception ex1) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex1);
            System.out.println("erreur lors de l'ajout");
        }*/
       
       try {
            for(Planning pp: planningService.getAllPlannings())
            {
                System.out.println(pp);
            }
        } catch (SQLException ex2) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex2);
            
        }
       
        /*try {
           planningService.modifierPlanning(2,"java","classe",40,"sidi bouzid");
      }catch (SQLException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("erreur lors de la modification");
        }
            
       try {
           planningService.modifierPlanning1(1,"uml");
      }catch (SQLException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("erreur lors de la modification");
        }
       
       try {
           planningService.modifierPlanning2(1,"diag de classe");
      }catch (SQLException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("erreur lors de la modification");
        }
       
       try {
           planningService.modifierPlanning3(1,50);
      }catch (SQLException ex12) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex12);
           System.out.println("erreur lors de la modification");
        }
       
       try {
           planningService.modifierPlanning4(1,"Tunis");
      }catch (SQLException ex10) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex10);
           System.out.println("erreur lors de la modification");
        }
       
        try {      
            planningService.supprimerPlanning(1);
        }catch (SQLException ex3) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex3);
            System.out.println("erreur lors de la suppression");
        }*/
       
    }
}
