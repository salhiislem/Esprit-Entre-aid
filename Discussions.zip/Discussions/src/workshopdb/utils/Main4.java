/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.applet.Main;
import workshopdb.entities.Etudiant;
import workshopdb.entities.InscriPlanning;
import workshopdb.entities.Planning;
import workshopdb.services.InscritEtudiant;
import workshopdb.services.PlanningService;

/**
 *
 * @author Hajbi
 */
public class Main4 {
    
    public static void main(String[] args) throws SQLException {
       
       Mydb1 database = Mydb1.getInstance();
       Connection connexion = Mydb1.getInstance().getConnection();
       InscritEtudiant inscritEtudiant= new InscritEtudiant();
       
       Planning p = new Planning("unix");
       Etudiant e = new Etudiant("sabri","ben marzouk");
       InscriPlanning I = new InscriPlanning(p,e);
        
       /*try {
            inscritEtudiant.InscritPlanning(p,e);
            System.out.println("planning ajouté");
        } catch (Exception ex1) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex1);
            System.out.println("erreur lors de l'ajout");
        }
         */
          try {
            for(InscriPlanning ii: inscritEtudiant.getAllInscriPlannings())
            {
                System.out.println(ii);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        
    }
}
