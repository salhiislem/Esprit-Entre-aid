/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.entities;

import java.sql.Date;

/**
 *
 * @author Hajbi
 */
public class Planning {
    private int idP;
    private String nom;
    private String sujet;
    private String prof;
    private int maximum;
    private String lieu;
    private String date;

    public Planning(int idP, String nom, String sujet,String prof, int maximum, String lieu, String date) {
        this.idP = idP;
        this.nom = nom;
        this.sujet = sujet;
        this.prof=prof;
        this.maximum = maximum;
        this.lieu = lieu;
        this.date=date;
    }

    public Planning(String nom, String sujet, String prof, int maximum, String lieu, String date) {
        this.nom = nom;
        this.sujet = sujet;
        this.prof=prof;
        this.maximum = maximum;
        this.lieu = lieu;
        this.date=date;
    }

    public Planning(String nom) {
        this.nom = nom;
    }

    public int getIdP() {
        return idP;
    }

    public String getNom() {
        return nom;
    }

    public String getSujet() {
        return sujet;
    }

    public String getProf() {
        return prof;
    }
    
    public int getMaximum() {
        return maximum;
    }

    public String getLieu() {
        return lieu;
    }

    public String getDate() {
        return date;
    }
    

    public void setIdP(int idP) {
        this.idP = idP;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setSujet(String sujet) {
        this.sujet = sujet;
    }

    public void setProf(String prof) {
        this.prof = prof;
    }

    public void setMaximum(int maximum) {
        this.maximum = maximum;
    }

    public void setLieu(String lieu) {
        this.lieu = lieu;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Planning{" + "idP=" + idP + ", nom=" + nom + ", sujet=" + sujet + ", prof=" + prof + ", maximum=" + maximum + ", lieu=" + lieu + ", date=" + date + '}';
    }


   
   
}
