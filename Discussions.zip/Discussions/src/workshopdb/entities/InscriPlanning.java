/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.entities;

import workshopdb.entities.Etudiant;
import workshopdb.entities.Planning;

/**
 *
 * @author Hajbi
 */
public class InscriPlanning {
    private String nomP;
    private String nomE;
    private String prenomE;
    public Etudiant e;
    public Planning p;

    public InscriPlanning(Planning p, Etudiant e) {
    }

    public InscriPlanning() {
    }

    public InscriPlanning(String nomP, String nomE,String prenomE) {
        this.nomP = p.getNom();
        this.nomE = e.getNomE();
        this.prenomE=e.getPrenomE();
    }

    
    
}
