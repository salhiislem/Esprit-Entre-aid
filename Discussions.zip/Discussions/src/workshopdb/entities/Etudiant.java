/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.entities;

/**
 *
 * @author Hajbi
 */
public class Etudiant {
    private String nomE;
    private String prenomE;

    public Etudiant(String nomE, String prenomE) {
        this.nomE = nomE;
        this.prenomE = prenomE;
    }

    
    
    public String getNomE() {
        return nomE;
    }

    public String getPrenomE() {
        return prenomE;
    }

    public void setNomE(String nomE) {
        this.nomE = nomE;
    }

    public void setPrenomE(String prenomE) {
        this.prenomE = prenomE;
    }

    @Override
    public String toString() {
        return "Etudiant{" + "nomE=" + nomE + ", prenomE=" + prenomE + '}';
    }
    
    
    
}
