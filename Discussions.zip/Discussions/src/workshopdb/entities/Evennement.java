/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.entities;

import java.sql.Date;
import java.text.SimpleDateFormat;

/**
 *
 * @author Hajbi
 */
public class Evennement {
    private int idE;
    private String nom;
    private String description,date;

    public Evennement(int idE, String nom, String description,String date) {
        this.idE = idE;
        this.nom = nom;
        this.description = description;
        this.date=date;
    }
    
    public Evennement (String nom, String description,String date) {
        this.nom = nom;
        this.description = description;
        this.date=date;
    }

    
    public int getIdE() {
        return idE;
    }

    public String getNom() {
        return nom;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }
    

    public void setIdE(int idE) {
        this.idE = idE;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Evennement{" + "idE=" + idE + ", nom=" + nom + ", description=" + description + ", date=" + date + '}';
    }
    

}