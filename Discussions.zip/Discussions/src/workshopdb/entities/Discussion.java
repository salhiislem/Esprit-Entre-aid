/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshopdb.entities;

/**
 *
 * @author Hajbi
 */
public class Discussion {
    private int idD;
    private String nom;
    private String sujet;

    public Discussion(int idD, String nom, String sujet) {
        this.idD = idD;
        this.nom = nom;
        this.sujet = sujet;
    
    }

    
    
    public Discussion(String nom, String sujet) {
        this.nom = nom;
        this.sujet = sujet;
    }

    public int getIdD() {
        return idD;
    }

    public String getNom() {
        return nom;
    }

    public String getSujet() {
        return sujet;
    }


    public void setIdD(int idD) {
        this.idD = idD;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setSujet(String sujet) {
        this.sujet = sujet;
    }

    @Override
    public String toString() {
        return "Discussion{" + "idD=" + idD + ", nom=" + nom + ", sujet=" + sujet + '}';
    }
    
    
    

}